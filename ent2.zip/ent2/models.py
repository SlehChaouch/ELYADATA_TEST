from sqlalchemy import Boolean, Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from database import Base

class FacebookPost(Base):
    __tablename__ = "posts"
    post_id = Column(String, primary_key=True, index=True)
    text = Column(String)
    time = Column(String)
    url = Column(String)

    scraping_id = Column(String, ForeignKey("results.id"))

    scrapingResult = relationship("ScrapingResult", back_populates="posts")

class ScrapingResult(Base):
    __tablename__ = "results"
    id = Column(String, primary_key=True, index=True)
    date =  Column(String)
    posts = relationship("FacebookPost", back_populates="scrapingResult")
