from facebook_scraper import get_posts
from schema import FacebookPost, ScrapingRequest, ScrapingResult
import uuid
import datetime
import crud
from sqlalchemy.orm import Session

def scrape(page, limit):
    posts = get_posts(page, pages = limit)
    l= [ FacebookPost(post_id = post["post_id"], text = post["text"], time = str(post["time"]), url = post["post_url"]) for post in posts ]
    print("finished scraping : " )
    print(posts)

    return l


def handle_scrape_query(db: Session,  req : ScrapingRequest):
    posts = scrape(req.page, req.limit)
    id_ =  str(uuid.uuid1())
    res = ScrapingResult(id =id_, date = str(datetime.datetime.now()), posts = posts)
    res = crud.persist_scraping(db, res)
    return res