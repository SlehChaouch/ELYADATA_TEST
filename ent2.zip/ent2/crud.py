from sqlalchemy.orm import Session
import uuid

import models, schema

def persist_scraping(db : Session, result : schema.ScrapingResult):
    posts = [models.FacebookPost(**post.dict()) for post in result.posts]
    result = models.ScrapingResult(id = result.id, date = result.id)
    db.add(result)
    for post in posts :
        post.scrapingResult = result
        post.post_id=str(uuid.uuid1())
        db.add(post)
    db.commit()
    db.refresh(result)
    return result

def get_result(db: Session, id : str ):
    return db.query(models.ScrapingResult).filter(models.ScrapingResult.id == id)

# return db.query(models.ScrapingResult).filter(models.ScrapingResult.id == )