from typing import List, Optional

from pydantic import BaseModel


class FacebookPost(BaseModel):
    post_id: str
    text : str
    time : str
    url : str

    class Config:
        orm_mode = True

class ScrapingResult(BaseModel):
    id : str
    date : str
    posts : List[FacebookPost]

    class Config:
        orm_mode = True

class ScrapingRequest(BaseModel):
    page : str
    limit : int