
from fastapi import Depends, FastAPI
from schema import ScrapingRequest
from database import SessionLocal, engine
from sqlalchemy.orm import Session
import scraper, models, schema, crud
models.Base.metadata.create_all(bind=engine)

app = FastAPI()

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.post("/requests/",response_model=schema.ScrapingResult)
async def scrape(request : ScrapingRequest, db: Session = Depends(get_db)):
    return scraper.handle_scrape_query(db,request )
